
package org.neos.cap1.test;
import org.neos.cap1.constants.TypeAnimal;
import org.neos.cap1.constants.Animals2;

public class TestAnimalType {

    public static void main(String[] args) {

      System.out.println(Animals2.ELEPHANT.isMammal());
      System.out.println(Animals2.TURTLE.isMammal());

    }

}
