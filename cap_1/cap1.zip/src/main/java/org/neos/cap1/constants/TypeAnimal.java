package  org.neos.cap1.constants;

public enum TypeAnimal{

  AMPHIBIAN,
  MAMMAL,
  REPTILE,
  BIRD
}
