package org.neos.cap1.business;

public interface IPersona {
    void miMetodo();
    void miMetodo(String mensaje);
}
