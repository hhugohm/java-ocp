package org.neos.cap1.test;
import org.neos.cap1.constants.Season3;

public class TestSeason3 {

      public static void main(String[] args) {

         System.out.println(Season3.SUMMER.name()+" "+ Season3.SUMMER.ordinal());
         Season3.SUMMER.printHours();
      }
}
