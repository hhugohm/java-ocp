package org.neos.cap1.test;

import org.neos.cap1.constants.Animals;

public class TestAnimals {

    public static void main(String[] args) {

      System.out.println(Animals.FROG.isMammal());
      System.out.println(Animals.DOG.isMammal());
    }
}
