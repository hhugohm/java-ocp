package  org.neos.cap1.constants;

public enum Season{

  WINTER,SPRING,SUMMER,FALL
}
